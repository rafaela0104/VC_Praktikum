# CMake generated Testfile for 
# Source directory: /home/rafaela/Uni/Semester4/VC/VC_Praktikum/OpenGL_Praktikum/libs/glm-master/test
# Build directory: /home/rafaela/Uni/Semester4/VC/VC_Praktikum/OpenGL_Praktikum/cmake-build-debug/libs/glm-master/test
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("bug")
subdirs("core")
subdirs("ext")
subdirs("gtc")
subdirs("gtx")


# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/rafaela/Uni/Semester4/VC/VC_Praktikum/OpenGL_Praktikum/libs/glm-master/glm/detail/dummy.cpp" "libs/glm-master/glm/CMakeFiles/glm_dummy.dir/detail/dummy.cpp.o" "gcc" "libs/glm-master/glm/CMakeFiles/glm_dummy.dir/detail/dummy.cpp.o.d"
  "/home/rafaela/Uni/Semester4/VC/VC_Praktikum/OpenGL_Praktikum/libs/glm-master/glm/detail/glm.cpp" "libs/glm-master/glm/CMakeFiles/glm_dummy.dir/detail/glm.cpp.o" "gcc" "libs/glm-master/glm/CMakeFiles/glm_dummy.dir/detail/glm.cpp.o.d"
  "" "libs/glm-master/glm/glm_dummy" "gcc" "libs/glm-master/glm/CMakeFiles/glm_dummy.dir/link.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
